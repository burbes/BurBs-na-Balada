﻿Ext.override(Ext.form.field.File, {
    setValue: function () {
        this.callParent(arguments);
    }
});