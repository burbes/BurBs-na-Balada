﻿Ext.Messages = {
    Endereco_Principal_Alterar: 'O Endereço Principal será alterado para este!',
    MeioComunicacao_Principal_Alterar: 'O Meio de Comunicação Principal será alterado para este!',
    Receita_Principal_Alterar: 'A Receita Principal será alterado para esta!'
};